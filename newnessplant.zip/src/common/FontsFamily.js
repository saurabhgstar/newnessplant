export const FONTS_FAMILY = {
  regular: 'Nunito-Regular',
  medium: 'Nunito-Medium',
  semi_bold: 'Nunito-SemiBold',
  bold: 'Nunito-Bold',
};

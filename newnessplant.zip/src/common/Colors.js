export const APP_COLORS = {
  white: '#FFFFFF',
  placeholder: '#F9F9F9',
  black: '#000000',
  primary: '#17AD5D',
  gray: '#D8D8D8',
  light_gray: '#D3D3D3',
  bright_gray: '#E8E8E8',
  active_placeholder: '#EEFAF4',
  active_border: '#52B36C',
  green: '#52B36C',
};

export const IMAGES = {
  logo: require('./logo.png'),
  email_icon: require('./email.png'),
  lock_icon: require('./lock.png'),
  eye_icon : require('./eye.png'),
  eye_close_icon: require('./eye_close.png')
};

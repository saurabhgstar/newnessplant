import {View, Text, Image, Alert} from 'react-native';
import React from 'react';
import CustomTextInput from '../../components/CustomTextInput/CustomTextInput';
import {styles} from './LoginScreenStyle';
import {IMAGES} from '../../assets/images/map';
import CustomButton from '../../components/CustomButton/CustomButton';

const LoginScreen = () => {
  return (
    <View style={styles.main}>
      <Text style={styles.loginText}>Login to Your Account</Text>

      <CustomTextInput
        placeholder={'Email'}
        isPassword={false}
        icon={IMAGES.email_icon}
      />
      <View
        style={{
          height: 20,
        }}
      />
      <CustomTextInput
        placeholder={'Password'}
        isPassword={true}
        icon={IMAGES.lock_icon}
      />
      <View
        style={{
          height: 20,
        }}
      />
      <CustomButton
        title={'Sign in'}
        onPress={() => {
          Alert.alert('alert');
        }}
      />
    </View>
  );
};

export default LoginScreen;

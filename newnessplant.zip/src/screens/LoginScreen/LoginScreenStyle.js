import {StyleSheet} from 'react-native';
import {APP_COLORS} from '../../common/Colors';
import {FONTS_FAMILY} from '../../common/FontsFamily';

export const styles = StyleSheet.create({
  main: {
    backgroundColor: APP_COLORS.white,
    flex: 1,
    padding: 25,
  },
  loginText: {
    textAlign: 'center',
    fontFamily: FONTS_FAMILY.bold,
    fontSize: 26,
    color: APP_COLORS.black,
  },
});

import {StyleSheet} from 'react-native';
import {APP_COLORS} from '../../common/Colors';

export const styles = StyleSheet.create({
  logoImage: {
    height: 250,
    width: 250,
  },
  main: {
    justifyContent: 'center',
    alignItems: 'center',
    alignContent: 'center',
    flex: 1,
    backgroundColor: APP_COLORS.white,
  },
});

import {View, Text, Image} from 'react-native';
import React, {useEffect} from 'react';
import {useNavigation} from '@react-navigation/native';
import {IMAGES} from '../../assets/images/map';
import {styles} from './SplashScreenStyle';

const SplashScreen = () => {
  const navigation = useNavigation();
  useEffect(() => {
    setTimeout(() => {
      navigation.navigate('LoginScreen');
    }, 2000);
  }, []);
  return (
    <View style={styles.main}>
      <Image source={IMAGES.logo} style={styles.logoImage} />
    </View>
  );
};

export default SplashScreen;

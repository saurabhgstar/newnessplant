import {View, Text, TextInput, Image, TouchableOpacity} from 'react-native';
import React, {useEffect, useState} from 'react';
import {styles} from './CustomTextInputStyle';
import {APP_COLORS} from '../../common/Colors';
import {IMAGES} from '../../assets/images/map';

const CustomTextInput = ({placeholder, isPassword, icon}) => {
  const [isVisible, setIsVisible] = useState(true);
  const [isFocused, setIsFocused] = useState(false);

  const handleFocus = () => {
    setIsFocused(true);
  };
  const handleBlur = () => {
    setIsFocused(false);
  };

  return (
    <View
      style={[
        styles.main,
        {
          borderColor: isFocused
            ? APP_COLORS.active_border
            : APP_COLORS.placeholder,
          borderWidth: 0.8,
          backgroundColor: isFocused
            ? APP_COLORS.active_placeholder
            : APP_COLORS.placeholder,
        },
      ]}>
      <>
        <Image source={icon} style={styles.icon} />
        <TextInput
          onBlur={handleBlur}
          onFocus={handleFocus}
          placeholder={placeholder}
          style={[styles.inputStyle]}
          secureTextEntry={isPassword ? isVisible : null}
          placeholderTextColor={APP_COLORS.black}
        />
      </>
      <TouchableOpacity
        onPress={() => {
          setIsVisible(!isVisible);
        }}>
        <Image
          source={
            isPassword
              ? isVisible
                ? IMAGES.eye_close_icon
                : IMAGES.eye_icon
              : null
          }
          style={styles.eyeIcon}
        />
      </TouchableOpacity>
    </View>
  );
};

export default CustomTextInput;

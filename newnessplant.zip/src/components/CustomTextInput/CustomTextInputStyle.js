import {Platform, StyleSheet} from 'react-native';
import {APP_COLORS} from '../../common/Colors';
import {FONTS_FAMILY} from '../../common/FontsFamily';

export const styles = StyleSheet.create({
  inputStyle: {
    width: '80%',
  },
  main: {
    paddingVertical: Platform.OS == 'ios' ? 20 : 5,
    paddingHorizontal: 15,
    borderRadius: 12,
    fontSize: 16,
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  icon: {
    height: 18,
    width: 18,
    alignSelf: 'center',
    marginRight: 15,
  },
  eyeIcon: {
    height: 25,
    width: 25,
    alignSelf: 'center',
  },
});

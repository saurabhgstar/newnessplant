import {StyleSheet} from 'react-native';
import {APP_COLORS} from '../../common/Colors';

export const styles = StyleSheet.create({
  button: {
    backgroundColor: APP_COLORS.green,
    padding: 15,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: APP_COLORS.white,
  },
});
